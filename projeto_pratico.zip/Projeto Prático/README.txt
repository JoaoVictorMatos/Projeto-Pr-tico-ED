
# README

## Desenvolvedores
- **João Paulo Silva** - Matrícula: 202420606
- **Otávio Augusto Silva** - Matrícula: 202120565
- **Luís Gustavo Morais Cardoso** - Matrícula: 202220819

##Sequence Set

## Sobre o Projeto
Este projeto implementa um Sequence Set ordenado com base no campo "value". Ele utiliza um arquivo binário para armazenar os dados e gerenciar a organização dos blocos, permitindo operações como inserção, busca, remoção, e alteração de registros.

### Estruturas
- **dado**: Estrutura para armazenar informações de registros individuais, como measure, quantile, area, entre outros.
- **cabecalho**: Gerencia o número de blocos, posição do primeiro bloco e o próximo bloco disponível.
- **bloco**: Estrutura que contém registros (dados) e informações de encadeamento para outros blocos.

### Funcionalidades
1. **inserir()**: Insere um novo registro no arquivo, garantindo a ordenação e divisão de blocos quando necessário.
2. **buscarRemoverAlterar()**: Busca registros com base no valor, permitindo exibição, remoção ou alteração dos dados.
3. **imprimir()**: Exibe todos os registros armazenados no arquivo binário.
4. **lerArquivo()**: Lê um arquivo CSV e insere os registros no Sequence Set.
5. **dividirBloco()** e **adicionarNoBloco()**: Gerenciam a adição de registros e divisão de blocos.

## Instruções de Uso
1. **Configuração Inicial**:
   - Certifique-se de que o arquivo binário `BaseDeDados.bin` está acessível no mesmo diretório do código.
   - Se o arquivo não existir, ele será criado automaticamente.

2. **Menu Principal**:
   - O programa inicia com um menu de opções:
     - 1: Leitura de arquivo CSV.
     - 2: Exibir registros.
     - 3: Adicionar registro manualmente.
     - 4: Buscar registro.
     - 5: Remover registro.
     - 6: Alterar registro.
     - 0: Sair do programa.

3. **Inserção de Dados**:
   - No caso de leitura de um arquivo CSV, certifique-se de que o arquivo esteja formatado corretamente e que todos os campos sejam preenchidos.

4. **Busca, Remoção e Alteração**:
   - Forneça o valor do campo "value" para localizar os registros desejados.

## Requisitos
- **Linguagem**: C++
- **Bibliotecas**: iostream, fstream, cstring, stdexcept
