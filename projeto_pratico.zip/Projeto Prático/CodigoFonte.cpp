//João Paulo Silva - Matrícula: 202420606
//Otávio Augusto Silva - Matrícula: 202120565
//Luís Gustavo Morais Cardoso - Matrícula: 202220819

#include <iostream>
#include <fstream>
#include <cstring>
#include <stdexcept>

using namespace std;

const int CAPACIDADE = 50;

struct dado{ //dados da tabela
    char measure[15];
    char quantile[20];
    char area[60];
    char sex[25];
    char age[45];
    char geography[70];
    char ethnic[30];
    double value;
};

struct cabecalho{ //cabeçalho do arquivo
    int numeroSeq; //número de blocos (pedaço, sequencias)
    int primeiroSeq; //posição do primeiro pedaço
    int proximoSeq; //posição do próximo pedaço disponível

    cabecalho(){
        numeroSeq = 1;
        primeiroSeq = 0;
        proximoSeq = 1;
    }
};

struct bloco{ //pedaço de sequência
    dado seq[CAPACIDADE]; //vetor de dados
    int qReg; //quantidade de registros no vetor
    int pSeq; //posição do próximo pedaço

    bloco(){
        qReg = 0;
        pSeq = -1;
    }
};

struct busca{
    dado correspondente;
    int posDado;
    int posBloco;
};

class sequenceSet{ //Sequence Set ordenado com baso no campo "Value"
    private:
        string nomeArquivo;

        void dividirBloco(int nBloco, dado novo){
            /*
            * Função responsável por dividir um bloco existente em dois blocos no arquivo binário e adicionar um novo dado no bloco correto.

            * 1. Abre o arquivo e lê o cabeçalho e o bloco a ser dividido.
            * 2. Verifica se o número de sequências do cabeçalho precisa ser atualizado. Se sim, incrementa o número de sequências e o próximo bloco.
            * 3. Divide o bloco, movendo os registros do meio até o fim para um novo bloco.
            * 4. Atualiza o cabeçalho, o bloco original e o novo bloco no arquivo binário.
            * 5. Verifica em qual bloco o novo dado deve ser adicionado e chama a função "adicionarNoBloco" com o número do bloco correspondente.
            */
            fstream arquivo(nomeArquivo,ios::in|ios::out|ios::binary);
            if (!arquivo) throw runtime_error("Erro ao abrir o arquivo: "+nomeArquivo);
            cabecalho cab;
            bloco blocoA, novoBloco;
            arquivo.seekg(0,ios::beg);
            arquivo.read(reinterpret_cast<char*>(&cab),sizeof(cabecalho));

            arquivo.seekg(sizeof(cabecalho)+nBloco*sizeof(bloco), ios::beg);
            arquivo.read(reinterpret_cast<char*>(&blocoA),sizeof(bloco));

            if (cab.proximoSeq == cab.numeroSeq){ //Se deve ser criado uma nova sequência
                novoBloco.pSeq = blocoA.pSeq;
                novoBloco.qReg = CAPACIDADE/2;
                blocoA.pSeq = cab.proximoSeq;
                blocoA.qReg = CAPACIDADE/2;
                cab.numeroSeq++;
                cab.proximoSeq++;
            } else { //Se existe uma sequencia vazia no Sequence Set
                arquivo.seekg(sizeof(cabecalho)+cab.proximoSeq*sizeof(bloco), ios::beg);
                arquivo.read(reinterpret_cast<char*>(&novoBloco),sizeof(bloco));

                int proximo = novoBloco.pSeq;

                novoBloco.pSeq = blocoA.pSeq;
                novoBloco.qReg = CAPACIDADE/2;
                blocoA.pSeq = cab.proximoSeq;
                blocoA.qReg = CAPACIDADE/2;
                cab.proximoSeq = proximo;
            }

            for (int i=0;i<CAPACIDADE/2;i++) novoBloco.seq[i] = blocoA.seq[CAPACIDADE/2+i]; //Copiando a metade final do vetor para o novo bloco

            //Posicionando o ponteiro de escrita e escrevendo o que foi atualizado
            arquivo.seekp(0, ios::beg);
            arquivo.write(reinterpret_cast<const char*>(&cab),sizeof(cabecalho));
            arquivo.seekp(sizeof(cabecalho)+nBloco*sizeof(bloco), ios::beg);
            arquivo.write(reinterpret_cast<const char*>(&blocoA),sizeof(bloco));
            arquivo.seekp(sizeof(cabecalho)+blocoA.pSeq*sizeof(bloco), ios::beg);
            arquivo.write(reinterpret_cast<const char*>(&novoBloco),sizeof(bloco));

            arquivo.close(); //Fechando o arquivo para a chamada da função "adicionarNoBloco"

            if (novo.value <= blocoA.seq[blocoA.qReg-1].value){ //Caso o novo dado deva ser adicionado na divisão 1 do bloco (blocoA)
                this->adicionarNoBloco(nBloco, novo);
                blocoA.qReg++;
            } else { //Caso deva ser adicionado na divisão 2 do bloco (novoBloco)
                this->adicionarNoBloco(blocoA.pSeq, novo);
                novoBloco.qReg++;
            }
        }
        void adicionarNoBloco (int nBloco, dado novo){
            /*
            * Função responsável por adicionar um novo registro em um bloco no arquivo binário.

            * 1. Abre o arquivo binário em modo leitura e escrita.
            * 2. Lança uma exceção se o arquivo não puder ser aberto.
            * 3. Lê o bloco especificado a partir da posição indicada no arquivo.
            * 4. Se o bloco não estiver vazio, encontra a posição adequada para inserir o novo registro, garantindo que a ordem dos registros seja mantida. 
            * 5. O novo registro é inserido na posição correta e o número de registros do bloco (`qReg`) é incrementado.
            * 6. Atualiza o bloco no arquivo.
            */
            fstream arquivo(nomeArquivo,ios::in|ios::out|ios::binary);
            if (!arquivo) throw runtime_error("Erro ao abrir o arquivo: "+nomeArquivo);
            bloco blocoA;
            arquivo.seekg(sizeof(cabecalho)+nBloco*sizeof(bloco), ios::beg);
            arquivo.read(reinterpret_cast<char*>(&blocoA),sizeof(bloco));

            int inicio = 0, fim = blocoA.qReg-1, meio;

            if (blocoA.qReg != 0){
                while (inicio < fim){ //Achando a posição de inserção com uma adaptação da busca binária
                    meio = (inicio+fim)/2;

                    if (blocoA.seq[meio].value == novo.value){
                        inicio = meio;
                        fim = meio;
                    } else if (novo.value < blocoA.seq[meio].value) {
                        fim = meio-1;
                    } else {
                        inicio = meio+1;
                    }
                }

                if (novo.value > blocoA.seq[inicio].value) inicio++; //Verificando se é maior em relação ao elemento em que foi parado

                for (int i=blocoA.qReg;i>inicio;i--) blocoA.seq[i]=blocoA.seq[i-1]; //Movendo os dados para frente para abrir espaço do dado a ser inserido
            }

            blocoA.seq[inicio]=novo;
            blocoA.qReg++;

            arquivo.seekp(sizeof(cabecalho)+nBloco*sizeof(bloco), ios::beg);
            arquivo.write(reinterpret_cast<const char*>(&blocoA),sizeof(bloco));

            arquivo.close();
        }
    public:
        sequenceSet(string nome = "BaseDeDados.bin"){
            nomeArquivo = nome;
        }
        
        void inserir(dado novo){
            /*
            * Função para inserir um novo registro no arquivo binário que representa o Sequence Set.

            * 1. A função abre o arquivo e lê o cabeçalho e os blocos existentes.
            * 2. Se houver apenas um bloco, insere o novo registro (adicionarNoBloco) ou divide o bloco e insere se estiver cheio (dividirBloco divide e já faz a inserção).
            * 3. Se houver mais de um bloco, percorre os blocos para encontrar a posição correta para o novo registro.
            */
            fstream arquivo(nomeArquivo,ios::in|ios::out|ios::binary);
            if (!arquivo) throw runtime_error("Erro ao abrir o arquivo: "+nomeArquivo);
            cabecalho cab;
            bloco blocoA, blocoB;
            arquivo.seekg(0,ios::beg);
            arquivo.read(reinterpret_cast<char*>(&cab),sizeof(cabecalho));
            
            arquivo.seekg(sizeof(cabecalho)+cab.primeiroSeq*sizeof(bloco),ios::beg);
            arquivo.read(reinterpret_cast<char*>(&blocoA),sizeof(bloco));

            if (cab.numeroSeq == 1){ //Se existir apenas um bloco
                if (blocoA.qReg == CAPACIDADE){
                    this->dividirBloco(cab.primeiroSeq, novo);
                } else {
                    this->adicionarNoBloco(cab.primeiroSeq, novo);
                }
            } else {
                arquivo.seekg(sizeof(cabecalho)+blocoA.pSeq*sizeof(bloco),ios::beg);
                arquivo.read(reinterpret_cast<char*>(&blocoB),sizeof(bloco));

                int BA = cab.primeiroSeq;
                int BB = blocoA.pSeq;

                while (!(novo.value >= blocoA.seq[blocoA.qReg-1].value && novo.value <= blocoB.seq[0].value) && !(novo.value <= blocoA.seq[blocoA.qReg-1].value) && (blocoB.pSeq != -1)){
                    BA = BB;
                    BB = blocoB.pSeq;
                    blocoA = blocoB;
                    arquivo.seekg(sizeof(cabecalho)+BB*sizeof(bloco),ios::beg);
                    arquivo.read(reinterpret_cast<char*>(&blocoB),sizeof(bloco));
                }

                if (!(novo.value > blocoA.seq[blocoA.qReg-1].value && novo.value <= blocoB.seq[0].value)){
                    if (!(novo.value <= blocoA.seq[blocoA.qReg-1].value)){
                        if (blocoB.qReg == CAPACIDADE) this->dividirBloco(BB,novo);
                        else this->adicionarNoBloco(BB, novo);
                    } else {
                        if (blocoA.qReg == CAPACIDADE) this->dividirBloco(BA, novo);
                        else this->adicionarNoBloco(BA, novo);
                    }
                } else {
                    if(blocoA.qReg == CAPACIDADE){
                        if (blocoB.qReg == CAPACIDADE){
                            this->dividirBloco(BA, novo);
                        } else {
                            this->adicionarNoBloco(BB, novo);
                        }
                    } else {
                        this->adicionarNoBloco(BA, novo);
                    }
                }
            }
            arquivo.close();
        }
        void buscarRemoverAlterar(const double valor, const int op){
            /*
            
            *A função buscarRemoverAlterar é responsável por buscar registros em um arquivo binário organizado em blocos encadeados,
            *com base em um valor fornecido. Dependendo da operação (op), ela permite:
            *Busca: Exibir os dados encontrados caso existam.
            *Remoção: Remover o dado encontrado, se houver mais de um, o usuário deve especificar qual ele deseja remover.
            *Alteração: Permite ao usuário modificar campos de um registro específico localizado pela busca, se houver mais de um, o usuário deve especificar qual ele deseja alterar.
            *Caso ele altere o campo "Value", o dado é reinserido no sequenceSet na posição correta
            *A função também garante o redimensionamento do vetor de busca quando necessário, valida entradas e mantém a consistência dos blocos no arquivo.
            
            */
            fstream arquivo(nomeArquivo,ios::in|ios::out|ios::binary);
            if (!arquivo) throw runtime_error("Erro ao abrir o arquivo: "+nomeArquivo);

            cabecalho cab;
            bloco blocoA, blocoB;
            arquivo.seekg(0,ios::beg);
            arquivo.read(reinterpret_cast<char*>(&cab),sizeof(cabecalho));
            
            arquivo.seekg(sizeof(cabecalho)+cab.primeiroSeq*sizeof(bloco),ios::beg);
            arquivo.read(reinterpret_cast<char*>(&blocoA),sizeof(bloco));

            int BA=cab.primeiroSeq, BB=blocoA.pSeq; //variáveis da posição dos blocos para escrita na remoção e alteração de dados

            if (blocoA.qReg == 0) { //Se o bloco inicial estiver vazio
                arquivo.close();
                throw runtime_error("Erro: Lista vazia!");
            }

            int capacidadeEncontrados = 5; //capacidade incial do vetor
            busca *encontrados = new busca[capacidadeEncontrados]; //vetor onde será armazenado os dados com valores iguais ao procurado
            int x = 0; //armazenar quantidade de elementos do vetor

            if (BB!=-1){ //Se existe um próximo bloco
                arquivo.seekg(sizeof(cabecalho)+BB*sizeof(bloco),ios::beg);
                arquivo.read(reinterpret_cast<char*>(&blocoB),sizeof(bloco));

                while (!(valor >= blocoA.seq[blocoA.qReg-1].value && valor <= blocoB.seq[0].value) && blocoB.pSeq!=-1 && !(valor < blocoA.seq[blocoA.qReg-1].value)){ //Procura os dois blocos de partida onde o valor pode estar
                    BA = BB;
                    BB = blocoB.pSeq;
                    blocoA = blocoB;
                    arquivo.seekg(sizeof(cabecalho)+BB*sizeof(bloco),ios::beg);
                    arquivo.read(reinterpret_cast<char*>(&blocoB),sizeof(bloco));
                }
            }

            if (valor <= blocoA.seq[blocoA.qReg-1].value) { //Se o valor estiver no BlocoA
                int i=0,j=blocoA.qReg-1,meio;
                while (i<=j){
                    meio = (i+j)/2;
                    if (valor == blocoA.seq[meio].value){
                        encontrados[x].correspondente = blocoA.seq[meio];
                        encontrados[x].posDado = meio;
                        encontrados[x].posBloco = BA;
                        x++;
                        i = j+1;
                    } else {
                        if (valor > blocoA.seq[meio].value) i = meio+1;
                        else j = meio-1;
                    }
                }
                
                int pos = meio-1;
                while (blocoA.seq[pos].value == valor && pos >= 0 && x!=0){ //Para verificar se existe dados com valores iguais à esquerda caso a quantidade de elementos no vetor seja != 0
                    if(x==capacidadeEncontrados){ //verificando se precisa redimensionar
                        busca *aux=new busca[capacidadeEncontrados+5];

                        memcpy(aux,encontrados,capacidadeEncontrados*sizeof(dado));

                        delete [] encontrados;
                        encontrados=aux;
                        capacidadeEncontrados+=5;
                    }
                    encontrados[x].correspondente = blocoA.seq[pos];
                    encontrados[x].posDado = pos;
                    encontrados[x].posBloco = BA;
                    x++;
                    pos--;
                }

                pos = meio+1;

                while (blocoA.seq[pos].value == valor && pos < blocoA.qReg && x!=0){ //agora para verificar se existe dados com valores iguais à direita
                    if(x==capacidadeEncontrados){
                        busca *aux=new busca[capacidadeEncontrados+5];

                        memcpy(aux,encontrados,capacidadeEncontrados*sizeof(dado));

                        delete [] encontrados;
                        encontrados=aux;
                        capacidadeEncontrados+=5;
                    }
                    encontrados[x].correspondente = blocoA.seq[pos];
                    encontrados[x].posDado = pos;
                    encontrados[x].posBloco = BA;
                    x++;
                    pos++;
                }
            }
            if (BB != -1){ //Agora verificando o próximo bloco se existir
                int i=0,j=blocoB.qReg-1,meio;
                while (i<=j){
                    meio = (i+j)/2;
                    if (valor == blocoB.seq[meio].value){
                        encontrados[x].correspondente = blocoB.seq[meio];
                        encontrados[x].posDado = meio;
                        encontrados[x].posBloco = BB;
                        x++;
                        i = j+1;
                    } else {
                        if (valor > blocoB.seq[meio].value) i = meio+1;
                        else j = meio-1;
                    }
                }
                int pos=meio-1;

                while (valor == blocoB.seq[pos].value && pos>=0 && x!=0){ //verificando à esquerda do dado com valor correspondente
                    if(x==capacidadeEncontrados){
                        busca *aux=new busca[capacidadeEncontrados+5];

                        memcpy(aux,encontrados,capacidadeEncontrados*sizeof(dado));

                        delete [] encontrados;
                        encontrados=aux;
                        capacidadeEncontrados+=5;
                    }
                    encontrados[x].correspondente = blocoB.seq[pos];
                    encontrados[x].posDado = pos;
                    encontrados[x].posBloco = BB;
                    x++;
                    pos--;
                }

                pos = meio+1;

                while (blocoB.seq[pos].value == valor && pos < blocoB.qReg && x!=0){ //verificando à direita do dado com valor correspondente
                    if(x==capacidadeEncontrados){
                        busca *aux=new busca[capacidadeEncontrados+5];

                        memcpy(aux,encontrados,capacidadeEncontrados*sizeof(dado));

                        delete [] encontrados;
                        encontrados=aux;
                        capacidadeEncontrados+=5;
                    }
                    encontrados[x].correspondente = blocoB.seq[pos];
                    encontrados[x].posDado = pos;
                    encontrados[x].posBloco = BB;
                    x++;
                    pos++;

                    if(blocoB.pSeq!=-1 && pos==blocoB.qReg){ //passando para o próximo bloco para continuar conferindo a existência de dados com mesmo valor
                        BB = blocoB.pSeq;
                        arquivo.seekg(sizeof(cabecalho)+blocoB.pSeq*sizeof(bloco),ios::beg);
                        arquivo.read(reinterpret_cast<char*>(&blocoB),sizeof(bloco));
                        pos=0;
                    }
                }
            }
            if (x == 0){ //se não encontrar nenhum dado com valor correspondente
                delete [] encontrados;
                arquivo.close();
                throw runtime_error("Erro: Nenhum Elemento Encontrado!");
            }
            
            int l=1;

            for (int i=0;i<x;i++){ //Mostrar os registros encontrados
                cout << "------------------------ Registro " << l << " -------------------------" << endl
                << "Measure: " << encontrados[i].correspondente.measure << endl
                << "Quantile: " << encontrados[i].correspondente.quantile << endl
                << "Area: " << encontrados[i].correspondente.area << endl
                << "Sex: " << encontrados[i].correspondente.sex << endl
                << "Age: " << encontrados[i].correspondente.age << endl
                << "Geography: " << encontrados[i].correspondente.geography << endl
                << "Ethnic: " << encontrados[i].correspondente.ethnic << endl
                << "Value: " << encontrados[i].correspondente.value << endl << endl;

                l+=1;
            }

            if (op == 5 or op == 6) { //Se a opção for de remover ou alterar o dado de valor correspondente
                bloco alterado;
                int n = 1;
                if (x>1){ //caso tenha encontrado mais de um dado com valor correspondente
                    cout << "Digite o número do registro correspondente: ";
                    cin >> n;
                    cout << endl;
                }

                n=n-1;

                arquivo.seekg(sizeof(cabecalho)+encontrados[n].posBloco*sizeof(bloco),ios::beg);
                arquivo.read(reinterpret_cast<char*>(&alterado),sizeof(bloco));

                if (op == 5){ //Se a opção for de remover determinado dado
                    for (int i=encontrados[n].posDado;i<alterado.qReg;i++) alterado.seq[i] = alterado.seq[i+1]; //Move os elementos da esquerda para a direita até o dado que será removido

                    alterado.qReg--; //Diminui 1 na quantidade de registros do vetor

                    if (alterado.qReg == 0){ //Caso o vetor fique vazio
                        bloco anterior;
                        arquivo.seekg(sizeof(cabecalho)+cab.primeiroSeq*sizeof(bloco),ios::beg);
                        arquivo.read(reinterpret_cast<char*>(&anterior),sizeof(bloco));

                        int nAnt = cab.primeiroSeq;

                        while (anterior.pSeq != encontrados[n].posBloco){ //Procura o bloco anterior a ele
                            nAnt = anterior.pSeq;
                            arquivo.seekg(sizeof(cabecalho)+anterior.pSeq*sizeof(bloco),ios::beg);
                            arquivo.read(reinterpret_cast<char*>(&anterior),sizeof(bloco));
                        }

                        anterior.pSeq = alterado.pSeq; //Faz o apontamento correto e salva no arquivo

                        arquivo.seekp(sizeof(cabecalho)+nAnt*sizeof(bloco), ios::beg);
                        arquivo.write(reinterpret_cast<const char *>(&anterior),sizeof(bloco));

                        alterado.pSeq = cab.proximoSeq; //O próximo bloco disponível do cabeçalho passa a ser o próximo do bloco vazio
                        cab.proximoSeq = encontrados[n].posBloco; //O bloco vazio passa a ser o próximo disponível do cabeçalho

                        arquivo.seekp(0, ios::beg);
                        arquivo.write(reinterpret_cast<const char *>(&cab),sizeof(cabecalho));
                    }
                    arquivo.seekp(sizeof(cabecalho)+encontrados[n].posBloco*sizeof(bloco), ios::beg);
                    arquivo.write(reinterpret_cast<const char *>(&alterado),sizeof(bloco));
                } else { //Se a opção for alterar
                    int opcao;
                    do{
                        cout << "\n--- Qual campo deseja alterar? \n\n"
                            << "1- Measure \n"
                            << "2- Quantile \n"
                            << "3- Area \n"
                            << "4- Sex \n"
                            << "5- Age \n"
                            << "6- Geography \n"
                            << "7- Ethnic \n"
                            << "8- Value \n"
                            << "0- Finalizar alterações \n\n";
                        cout << "Opção: ";

                        cin >> opcao;
                        cin.ignore();

                        switch(opcao){
                            case 1:
                                cout << "New Measure: ";
                                cin.getline(alterado.seq[encontrados[n].posDado].measure,15);
                                break;
                            case 2:
                                cout << "New Quantile: ";
                                cin.getline(alterado.seq[encontrados[n].posDado].quantile,20);
                                break;
                            case 3:
                                cout << "New Area: ";
                                cin.getline(alterado.seq[encontrados[n].posDado].area,60);
                                break;
                            case 4:
                                cout << "New Sex: ";
                                cin.getline(alterado.seq[encontrados[n].posDado].sex,25);
                                break;
                            case 5:
                                cout << "New Age: ";
                                cin.getline(alterado.seq[encontrados[n].posDado].age,45);
                                break;
                            case 6:
                                cout << "New Geography: ";
                                cin.getline(alterado.seq[encontrados[n].posDado].geography,70);
                                break;
                            case 7:
                                cout << "New Ethnic: ";
                                cin.getline(alterado.seq[encontrados[n].posDado].ethnic,30);
                                break;
                            case 8:{ //Se o valor for alterado, ele precisa ser removido da posição atual e reinserido na posição correta
                                dado xAlterado = alterado.seq[encontrados[n].posDado];
                                cout << "New Value: "; 
                                cin >> xAlterado.value;

                                for (int i=encontrados[n].posDado;i<alterado.qReg;i++) alterado.seq[i] = alterado.seq[i+1]; //Move os elementos da esquerda do dado que será removido até o final
                                alterado.qReg--; //Diminui 1 na quantidade de registros do vetor

                                if (alterado.qReg == 0){ //Caso o vetor fique vazio
                                    bloco anterior;
                                    arquivo.seekg(sizeof(cabecalho)+cab.primeiroSeq*sizeof(bloco),ios::beg);
                                    arquivo.read(reinterpret_cast<char*>(&anterior),sizeof(bloco));

                                    int nAnt = cab.primeiroSeq;

                                    while (anterior.pSeq != encontrados[n].posBloco){ //Procura o bloco anterior a ele
                                        nAnt = anterior.pSeq;
                                        arquivo.seekg(sizeof(cabecalho)+anterior.pSeq*sizeof(bloco),ios::beg);
                                        arquivo.read(reinterpret_cast<char*>(&anterior),sizeof(bloco));
                                    }

                                    anterior.pSeq = alterado.pSeq; //Faz o apontamento correto e salva no arquivo

                                    arquivo.seekp(sizeof(cabecalho)+nAnt*sizeof(bloco), ios::beg);
                                    arquivo.write(reinterpret_cast<const char *>(&anterior),sizeof(bloco));

                                    alterado.pSeq = cab.proximoSeq; //O próximo bloco disponível do cabeçalho passa a ser o próximo do bloco vazio
                                    cab.proximoSeq = encontrados[n].posBloco; //O bloco vazio passa a ser o próximo disponível do cabeçalho

                                    arquivo.seekp(0, ios::beg);
                                    arquivo.write(reinterpret_cast<const char *>(&cab),sizeof(cabecalho));
                                }

                                arquivo.seekp(sizeof(cabecalho)+encontrados[n].posBloco*sizeof(bloco), ios::beg);
                                arquivo.write(reinterpret_cast<const char *>(&alterado),sizeof(bloco));

                                arquivo.close();
                                delete [] encontrados;

                                this->inserir(xAlterado);

                                cout << "\n--- O registro foi reposicionado devido a alteração do Valor!\n" << endl;

                                return;

                                break;
                            }
                            case 0:
                                break;
                            default:
                                cout << "Opção inválida! Tente novamente.\n\n";
                        }
                    } while (opcao != 0);
                    arquivo.seekp(sizeof(cabecalho)+encontrados[n].posBloco*sizeof(bloco), ios::beg);
                    arquivo.write(reinterpret_cast<const char *>(&alterado),sizeof(bloco));
                }
            }
            delete [] encontrados;
            arquivo.close();
        }
        
        void imprimir(){
            /* 
            * Função para imprimir os registros armazenados em um arquivo binário. 
            * Ela lê o cabeçalho e os blocos do arquivo, exibindo as informações dos registros contidos em cada bloco seguindo a ordem dos blocos.
            */
            fstream arquivo(nomeArquivo,ios::in|ios::out|ios::binary);
            if (!arquivo) throw runtime_error("Erro ao abrir o arquivo: "+nomeArquivo);

            cabecalho cab;
            bloco atual;

            arquivo.seekg(0,ios::beg);
            arquivo.read(reinterpret_cast<char*>(&cab),sizeof(cabecalho));
            arquivo.seekg(sizeof(cabecalho)+cab.primeiroSeq*sizeof(bloco),ios::beg);
            arquivo.read(reinterpret_cast<char*>(&atual),sizeof(bloco));

            if (atual.qReg == 0) { //Se o bloco inicial estiver vazio
                arquivo.close();
                throw runtime_error("Erro: Lista vazia!");
            }

            int BA = cab.primeiroSeq;

            //Impressão do primeiro bloco
            cout << "====================================== Cabeçalho ======================================\n";
            cout << "Quantidade total de blocos: " << cab.numeroSeq << "\n";
            cout << "Primeiro bloco: " << cab.primeiroSeq << "\n";
            cout << "Próximo bloco disponível: " << cab.proximoSeq << "\n\n";

            cout << "====================================== Contêiner " << BA << " ======================================\n";
            cout << "--- Quantidade de elementos no bloco: " << atual.qReg << "\n";
            cout << "--- Número do próximo bloco: " << atual.pSeq << "\n\n";
            
            int l=1;

            for (int i=0;i<atual.qReg;i++){
                cout << "-------------------- Registro " << l << " --------------------" << endl
                << "Measure: " << atual.seq[i].measure << endl
                << "Quantile: " << atual.seq[i].quantile << endl
                << "Area: " << atual.seq[i].area << endl
                << "Sex: " << atual.seq[i].sex << endl
                << "Age: " << atual.seq[i].age << endl
                << "Geography: " << atual.seq[i].geography << endl
                << "Ethnic: " << atual.seq[i].ethnic << endl
                << "Value: " << atual.seq[i].value << endl << endl;

                l+=1;
            }

            while (atual.pSeq != -1){ //Impressão dos demais blocos, se existir
                BA = atual.pSeq;
                arquivo.seekg(sizeof(cabecalho)+atual.pSeq*sizeof(bloco),ios::beg);
                arquivo.read(reinterpret_cast<char*>(&atual),sizeof(bloco));

                cout << "====================================== Contêiner " << BA << " ======================================\n";
                cout << "--- Quantidade de elementos no bloco: " << atual.qReg << "\n";
                cout << "--- Número do próximo bloco: " << atual.pSeq << "\n\n";

                for (int i=0;i<atual.qReg;i++){
                    cout << "------------------------ Registro " << l << " -------------------------" << endl
                    << "Measure: " << atual.seq[i].measure << endl
                    << "Quantile: " << atual.seq[i].quantile << endl
                    << "Area: " << atual.seq[i].area << endl
                    << "Sex: " << atual.seq[i].sex << endl
                    << "Age: " << atual.seq[i].age << endl
                    << "Geography: " << atual.seq[i].geography << endl
                    << "Ethnic: " << atual.seq[i].ethnic << endl
                    << "Value: " << atual.seq[i].value << endl << endl;

                    l+=1;
                }
            }

            arquivo.close();
        }
        void lerArquivo(string nomeArquivo){
            /*
            * Função para ler um arquivo CSV e inserir os dados no Sequence Set.

            * O arquivo é aberto em modo leitura, e os dados de cada linha são extraídos e armazenados na estrutura 'dado'.
            * Caso haja erro ao abrir o arquivo, é lançada uma exceção do tipo 'runtime_error' com a mensagem de erro.
            * Cada registro extraído é inserido no Sequence Set utilizando a função 'inserir'.
            * Cada campo do registro é lido e processado separadamente por meio de 'getline' e uma leitura adicional para o valor numérico final.
            */
            ifstream arqCSV (nomeArquivo);
            if (!arqCSV){
                throw runtime_error("Erro ao abrir o arquivo: "+nomeArquivo);
            }
            dado x;
            string linha;
            getline(arqCSV, linha);

            while (arqCSV.getline(x.measure,15,',')){ //Recebe os dados enquanto puder
                arqCSV.getline(x.quantile,20,',');
                arqCSV.getline(x.area,60,',');
                arqCSV.getline(x.sex,25,',');
                arqCSV.getline(x.age,45,',');
                arqCSV.getline(x.geography,70,',');
                arqCSV.getline(x.ethnic,30,',');
                arqCSV >> x.value;
                arqCSV.ignore();
                arqCSV.ignore();

                this->inserir(x); //Insere o dado no SequenceSet
            }
            arqCSV.close();
        }
};

int main () {
    ifstream arquivoExistente("BaseDeDados.bin",ios::in|ios::out|ios::binary);

	if (!arquivoExistente) {  // Se o arquivo não existe, cria e escreve os dados
		ofstream z("BaseDeDados.bin", ios::binary);
		cabecalho x;
		bloco y;

		z.seekp(0, ios::beg);  // Posiciona o ponteiro de escrita no início
		z.write(reinterpret_cast<const char *>(&x), sizeof(cabecalho));  // Escreve o cabeçalho
		z.seekp(sizeof(cabecalho), ios::beg);  // Posiciona o ponteiro após o cabeçalho
		z.write(reinterpret_cast<const char *>(&y), sizeof(bloco));  // Escreve o bloco

		z.close();  // Fecha o arquivo
		cout << "Arquivo criado e dados escritos com sucesso!" << endl;
	} else {  // Se o arquivo já existe, verifica se está vazio e escreve os dados
		// Verificar se o arquivo está vazio
		arquivoExistente.seekg(0, ios::end);
		if (arquivoExistente.tellg() == 0) {  // Se o arquivo estiver vazio
			cabecalho x;
			bloco y;

			// Escrever os dados no arquivo
			ofstream z("BaseDeDados.bin", ios::binary | ios::app);  // Abrir para escrita no final do arquivo
			z.seekp(0, ios::beg);  // Posiciona o ponteiro de escrita no início
			z.write(reinterpret_cast<const char *>(&x), sizeof(cabecalho));  // Escreve o cabeçalho
			z.seekp(sizeof(cabecalho), ios::beg);  // Posiciona o ponteiro após o cabeçalho
			z.write(reinterpret_cast<const char *>(&y), sizeof(bloco));  // Escreve o bloco
			z.close();  // Fecha o arquivo

			// Exibir os dados como solicitado
			cout << "Sequências de Blocos: " << x.numeroSeq << "\n"
				 << "Primeiro Bloco da Sequência: " << x.primeiroSeq << "\n"
				 << "Próximo Bloco: " << x.proximoSeq << endl;
			cout << "Criar Bloco: " << y.pSeq << "\n" << "Quantidade de Registros: " << y.qReg << endl;
		} else {  // Se o arquivo já contiver dados
			cout << "Arquivo encontrado. Dados carregados com sucesso!" << endl;
		}
	}
    sequenceSet operacaoDe;
    cout << "******** Bem-vindo à Criação do SequenceSet **********\n";
    int opcao;

    do{
        try{
            cout << "\nMenu de opções:\n";
            cout << "1 - Leitura de arquivo\n";
            cout << "2 - Exibir registros\n";
            cout << "3 - Adicionar registro\n";
            cout << "4 - Buscar registro\n";
            cout << "5 - Remover Registro\n";
            cout << "6 - Alterar Registro\n";
            cout << "0 - Sair\n";
            cout << "Opção: ";
            cin >> opcao;

            switch (opcao) {
                case 1: { //Ler arquivo e adicionar no sequence set
                    cout << "Digite o nome do arquivo a ser lido: ";
                    string nomeArquivo;
                    cin >> nomeArquivo;
                    operacaoDe.lerArquivo(nomeArquivo);
                    cout << "Arquivo lido com sucesso!\n";
                    break;
                }
                case 2: //Exibir todos os registros do sequence set
                    cout << "\nExibindo registros:\n";
                    operacaoDe.imprimir();
                    break;
                case 3: //Adicionar um registro
                    dado x;
                    cin.ignore();
                    cout << "New Measure: ";
                    cin.getline(x.measure, 15);
                    cout << "New Quantile: ";
                    cin.getline(x.quantile, 20);
                    cout << "New Area: ";
                    cin.getline(x.area, 60);
                    cout << "New Sex: ";
                    cin.getline(x.sex, 25);
                    cout << "New Age: ";
                    cin.getline(x.age, 45);
                    cout << "New Geography: ";
                    cin.getline(x.geography, 70);
                    cout << "New Ethnic: ";
                    cin.getline(x.ethnic, 30);
                    cout << "New Value: ";
                    cin >> x.value;
                    cin.ignore();
                    operacaoDe.inserir(x);
                    cout << "Registro inserido com sucesso!\n";
                    break;
                case 4: //Buscar e exibir um registro
                    cout << "Digite o valor do registro a ser buscado: ";
                    double valor;
                    cin >> valor;
                    cout << endl;
                    operacaoDe.buscarRemoverAlterar(valor, 4);
                    break;
                case 5: //Buscar e remover um registro
                    cout << "Digite o valor do registro a ser removido: ";
                    double valor1;
                    cin >> valor1;
                    cout << endl;
                    operacaoDe.buscarRemoverAlterar(valor1, 5);
                    cout << "Registro removido com sucesso!\n";
                    break;
                case 6: //Buscar e alterar um registro
                    cout << "Digite o valor do registro a ser alterado: ";
                    double valor2;
                    cin >> valor2;
                    cout << endl;
                    operacaoDe.buscarRemoverAlterar(valor2, 6);
                    cout << "Registro alterado com sucesso!\n";
                    break;
                case 0: //Sair do Programa
                    cout << "Saindo...\n";
                    break;
                default:
                    cout << "Opção inválida! Tente novamente.\n";
            }
        } catch (runtime_error& e) {
            cout << e.what() << endl;
        }
    } while (opcao != 0);

    return 0;
}